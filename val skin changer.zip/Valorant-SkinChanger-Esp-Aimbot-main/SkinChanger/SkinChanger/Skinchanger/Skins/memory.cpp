/*
 * memory.cpp
 *
 *  Created on: Feb 3, 2018
 *      Author: nullifiedcat
 */

#include "memory.hpp"

namespace memory
{

pid_t active_process;
}
